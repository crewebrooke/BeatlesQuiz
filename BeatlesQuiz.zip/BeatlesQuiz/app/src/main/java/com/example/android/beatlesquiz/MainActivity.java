package com.example.android.beatlesquiz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    int correctAnswers = 0;
    Button submitScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        submitScore = (Button) findViewById(R.id.submitScore);
        submitScore.setOnClickListener(submitScoreOnClickListener);
    }

    /**
     * This method is called when Q1 is answered.
     */
    private void QuestionOne() {
        CheckBox questionOneGeorge = (CheckBox) findViewById(R.id.question1George);
        CheckBox questionOneRingo = (CheckBox) findViewById(R.id.question1Ringo);
        CheckBox questionOnePaul = (CheckBox) findViewById(R.id.question1Paul);
        boolean isGeorgeChecked = questionOneGeorge.isChecked();
        boolean isRingoChecked = questionOneRingo.isChecked();
        boolean isPaulChecked = questionOnePaul.isChecked();

        if (isRingoChecked && isPaulChecked) {
            correctAnswers += 1;
        }
    }

    /**
     * This method is called when Q2 is answered.
     */
    private void QuestionTwo() {
        RadioButton ericnotInBeatles = (RadioButton) findViewById(R.id.question2Eric);
        RadioButton johnnotInBeatles = (RadioButton) findViewById(R.id.question2John);
        RadioButton ringonotInBeatles = (RadioButton) findViewById(R.id.question2Ringo);
        boolean isEricChecked = ericnotInBeatles.isChecked();
        if (isEricChecked) {
            correctAnswers += 1;

        }
    }

    /**
     * This method is called when Q3 is answered.
     */
    private void QuestionThree() {
        RadioButton johnandCrickets = (RadioButton) findViewById(R.id.question3John);
        RadioButton theSkiffleMen = (RadioButton) findViewById(R.id.question3Skiffle);
        RadioButton theQuarryMen = (RadioButton) findViewById(R.id.question3Quarry);
        boolean isQuarryChecked = theQuarryMen.isChecked();
        if (isQuarryChecked) {
            correctAnswers += 1;

        }
    }

    /**
     * This method is called when Q4 is answered.
     */
    private void QuestionFour() {
        RadioButton abbeyRoad = (RadioButton) findViewById(R.id.question4Abbey);
        RadioButton letItBe = (RadioButton) findViewById(R.id.question4Letitbe);
        RadioButton revolver = (RadioButton) findViewById(R.id.question4Revolver);
        boolean isLetItBeChecked = letItBe.isChecked();
        if (isLetItBeChecked) {
            correctAnswers += 1;
        }

    }

    /**
     * This method is called when Q5 is answered.
     */
    private String Question5() {
        EditText addText = (EditText) findViewById(R.id.name_field);
        String name = addText.getText().toString();
        return name;
    }

    private void Question5Answer() {
        String name = Question5();
        if (name.equalsIgnoreCase("liverpool")) {
            correctAnswers += 1;
        }

    }

    /**
     * This method calculates the 5 questions are correct
     */
    private void checkAnswers(){
        QuestionOne();
        QuestionTwo();
        QuestionThree();
        QuestionFour();
        Question5Answer();
    }

    private void resetCounterCorrectAnswers(){
        correctAnswers = 0;
    }

    final View.OnClickListener submitScoreOnClickListener = new View.OnClickListener() {
        public void onClick(final View v){
            checkAnswers();
            Toast.makeText(MainActivity.this, "Correct Answers: " + correctAnswers + "/5",
                    Toast.LENGTH_SHORT).show();
            resetCounterCorrectAnswers();
        }
    };
}




